package com.example.application.repositories;

import com.example.application.persistence.Invoice;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;
 
public interface InvoiceRepository extends CrudRepository<Invoice, Long> {
    
    @Modifying
    @Query(value = "DELETE FROM invoices" + " WHERE invoice_number = ?", nativeQuery = true)
    @Transactional(rollbackFor = Exception.class)
    int delete(Long invoice);

}