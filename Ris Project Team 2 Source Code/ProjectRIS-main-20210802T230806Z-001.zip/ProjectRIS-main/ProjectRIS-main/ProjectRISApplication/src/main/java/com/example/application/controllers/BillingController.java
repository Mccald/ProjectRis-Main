package com.example.application.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import java.util.ArrayList;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import com.example.application.persistence.Appointment;
import com.example.application.persistence.Invoice;
import com.example.application.persistence.Modality;
import com.example.application.persistence.Patient;
import com.example.application.persistence.User;
import com.example.application.repositories.AppointmentRepository;
import com.example.application.repositories.ModalityRepository;
import com.example.application.repositories.PatientRepository;
import com.example.application.repositories.UserRepository;
import com.example.application.repositories.InvoiceRepository;

@Controller 
public class BillingController {

  
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private AppointmentRepository appointmentRepository;
    @Autowired
    private ModalityRepository modalityRepository;

    @Autowired
    private InvoiceRepository InvoiceRepository;


    @GetMapping("/billing")
    public String billingView(HttpSession session, Model model){

         //////////////////////////////// creates and populates the invoice list//////////////////////
        Iterable<Invoice> invoices_list = InvoiceRepository.findAll();
        ArrayList<Invoice> complete_invoices_list = new ArrayList<Invoice>();

        for(Invoice invoice : invoices_list){

 
            Optional<Appointment> find_appointment = appointmentRepository.findById(invoice.getAppointment());
            if(find_appointment.isPresent())
            {
                invoice.setAppointmentObject(find_appointment.get());
            }

            complete_invoices_list.add(invoice);
        }
    
        model.addAttribute("invoices_list", complete_invoices_list);
        /////////////////////////////////////////////////////////////////////////////////////////////////

       //////////////////////////////// creates and populates the appointment list//////////////////////
        Iterable<Appointment> appointments_list = appointmentRepository.findAll();
        ArrayList<Appointment> complete_appointments_list = new ArrayList<Appointment>();

        for(Appointment appointment : appointments_list)
        {
            Optional<Patient> find_patient = patientRepository.findById(appointment.getPatient());
            if(find_patient.isPresent())
            {
                appointment.setPatientObject(find_patient.get());
            }
            
            Optional<Modality> find_modality = modalityRepository.findById(appointment.getModality());
            if(find_modality.isPresent())
            {
                appointment.setModalityObject(find_modality.get());
            }
            
            Optional<User> find_radiologist = userRepository.findById(appointment.getRadiologist());
            if(find_radiologist.isPresent())
            {
                appointment.setRadiologistObject(find_radiologist.get());
            }
            
            Optional<User> find_technician = userRepository.findById(appointment.getTechnician());
            if(find_technician.isPresent())
            {
                appointment.setTechnicianObject(find_technician.get());
            }

            complete_appointments_list.add(appointment);
        }

        model.addAttribute("appointments_list", complete_appointments_list);
        model.addAttribute("invoice", new Invoice());
        model.addAttribute("delete", new Invoice());
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

        return "billing";
    }

    
    @PostMapping("/delete")
    public String delete(@ModelAttribute("delete") Invoice invoice, Model model, BindingResult result)
    {
     
        InvoiceRepository.delete(invoice.getInvoice_number());
       
        return "redirect:/billing";
    }

    @PostMapping("/updateInvoice")
    public String updateInvoice(@ModelAttribute("invoice") Invoice invoice, Model model, BindingResult result)
    {
       InvoiceRepository.save(invoice);

        return "created_invoice";
    }


}
// NEW STUFF