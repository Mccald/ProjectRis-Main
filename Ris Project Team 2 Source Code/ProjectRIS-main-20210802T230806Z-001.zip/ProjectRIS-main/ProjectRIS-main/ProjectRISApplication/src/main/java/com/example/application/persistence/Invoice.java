package com.example.application.persistence;
import javax.persistence.*;
 
@Entity
@Table(name = "invoices")
public class Invoice {
    @Id
    @Column(name = "invoice_number")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long invoice_number;


    @Column(name = "appointment")
    private Long appointment;


   
    @Transient
    private Appointment appointmentObject;



    // getters

    public Long getInvoice_number() {
        return this.invoice_number;
    }
    

    public Appointment getAppointmentObject() {
        return this.appointmentObject;
    }

    public Long getAppointment() {
        return this.appointment;
    }
    
    public Long getId() {
        return this.invoice_number;
    }

    // setters

    public void setInvoice_number(Long invoice_number){
        this.invoice_number = invoice_number;
    }

    public void setAppointmentObject(Appointment appointmentObject){
        this.appointmentObject = appointmentObject;
    }

    public void setAppointment(Long appointment){
        this.appointment = appointment;
    }


  
}
